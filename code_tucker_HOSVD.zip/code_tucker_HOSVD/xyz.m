x=randi([0 30],3,3,3);
%d=x.tensor
X=tensor(x);